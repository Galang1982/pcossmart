export const symptomLabels: Record<string,string> = {
  nyeri_perut:"Nyeri perut", jerawat:"Jerawat", rambut_rontok:"Rambut rontok",
  rambut_berlebih:"Rambut tumbuh berlebih", lelah:"Lelah", cemas:"Cemas",
  kembung:"Kembung", sulit_tidur:"Sulit tidur"
};
export const categoryLabels: Record<string,string> = {
  apa_itu_pcos:"Apa itu PCOS", makanan:"Makanan", aktivitas_fisik:"Aktivitas fisik",
  tidur_stres:"Tidur & stres", kapan_ke_dokter:"Kapan ke dokter"
};
export const intensityLabels: Record<string,string> = { ringan:"Ringan", sedang:"Sedang", deras:"Deras" };
