export function localDate(d=new Date()) { const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),day=String(d.getDate()).padStart(2,"0"); return `${y}-${m}-${day}`; }
export function shiftDate(date:string,days:number) { const d=new Date(`${date}T12:00:00`); d.setDate(d.getDate()+days); return localDate(d); }
