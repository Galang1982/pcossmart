export type Checkin = { checkin_date:string; on_period:boolean; symptoms:string[]; energy:number; mood:number; sleep_hours:number|null };
export function summarizeCheckins(rows:Checkin[]) {
 const counts:Record<string,number>={}; rows.forEach(r=>(r.symptoms||[]).forEach(s=>counts[s]=(counts[s]||0)+1));
 const frequent=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,5);
 const dates=rows.filter(r=>r.on_period).map(r=>r.checkin_date).sort();
 const starts=dates.filter((d,i)=>i===0 || (new Date(d+"T12:00:00").getTime()-new Date(dates[i-1]+"T12:00:00").getTime())>86400000);
 const lengths=starts.slice(1).map((d,i)=>Math.round((new Date(d+"T12:00:00").getTime()-new Date(starts[i]+"T12:00:00").getTime())/86400000));
 return {frequent,cycle:lengths.length?{average:Math.round(lengths.reduce((a,b)=>a+b,0)/lengths.length),min:Math.min(...lengths),max:Math.max(...lengths)}:null};
}
