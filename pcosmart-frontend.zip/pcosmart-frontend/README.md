# PCOSmart Frontend

Frontend React + Vite + TypeScript untuk PCOSmart. Implementasi mengikuti `API Contract PCOSmart v1.0` yang disertakan bersama backend.

## Menjalankan

```bash
npm install
cp .env.example .env
# Isi VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY
npm run dev
```

## Fitur yang terhubung ke kontrak backend

- Supabase Auth: daftar, login, logout.
- Onboarding: `profiles` (nickname, age_range, consent_at).
- Daily check-in: upsert `daily_checkins` berdasarkan user_id + checkin_date.
- Smart tracker: baca riwayat 90 hari, hitung gejala teratas dan siklus yang teramati.
- AI companion: `functions.invoke('chat')`, baca riwayat `chat_messages`, perlakuan error dan flag.
- Edukasi: daftar/detail `education_articles`.
- Ekspor data pribadi: unduh `pcosmart-data.json`.
- Disclaimer non-diagnostik.

## Catatan integrasi penting

Dokumen API Contract v1.0 mendefinisikan `daily_checkins.checkin_date`, `symptoms`, `energy` dan `mood` sebagai integer 1–5. Namun migration SQL yang ada di ZIP backend mendefinisikan `check_date`, belum memiliki `symptoms`, dan `energy`/`mood` bertipe text. Implementasi frontend ini mengikuti API Contract, bukan mengarang kompatibilitas. Backend perlu menyelaraskan migration dengan kontrak sebelum daily check-in dapat tersimpan. Jangan mengubah migration backend diam-diam.

API Contract juga menyebut `profiles.nickname` dan `age_range`; migration awal yang diberikan hanya mendefinisikan `full_name`. Pastikan migration backend terbaru sudah menambahkan field kontrak tersebut.

PRD menyebut Meal Analyzer, voice-to-text journaling, dan activity recommender. Ketiganya belum tersedia dalam backend ZIP (yang tersedia: Auth/profil, daily check-in sesuai skema awal, edukasi, dan chat). Fitur tersebut tidak dibuat seolah-olah sudah berfungsi. Meal Analyzer dan voice journal tidak ditampilkan sebagai fitur aktif.

## Environment

Hanya gunakan Supabase URL dan anon/publishable key di browser. Jangan masukkan `service_role`, Gemini, atau Groq API key ke `.env` frontend.

## Verifikasi

```bash
npm run typecheck
npm run build
```
